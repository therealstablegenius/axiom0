---
doc_id: sample-code-ch2
title: SAMPLE Code, Chapter 2 (fictional test fixture, not official text)
authority: ordinance
effective: 2026-03-01
---
Sec. 2-13. Use of council chambers for special events.
The council chambers may be reserved for weddings and other special events when the council is not in session. A request for reservation shall be submitted to the city clerk at least fourteen days before the event. The city clerk shall confirm or decline each request in writing within five business days.

Sec. 2-14. Fees for chamber reservations.
A reservation fee shall be paid before the reservation is confirmed. The fee schedule shall be set by the city clerk and published on the city website.
