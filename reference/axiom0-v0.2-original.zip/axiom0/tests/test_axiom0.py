import json
import os
import sqlite3
from datetime import date, timedelta

import pytest

from axiom0.access import AccessDenied
from axiom0.core import Axiom0
from axiom0.ledger import Ledger
from axiom0.lineage import V01_PACKAGE_SHA256, check_v01
from axiom0.proof import check_claims
from axiom0.truth import TruthLibrary
from axiom0.warning import SpikeRule, spikes

HERE = os.path.dirname(__file__)
SOURCES = os.path.join(HERE, "..", "samples", "sources")
CSV = os.path.join(HERE, "..", "samples", "service_requests_sample.csv")


@pytest.fixture
def ax(tmp_path):
    with open(tmp_path / "users.json", "w") as f:
        json.dump({"howard": "admin", "ana": "analyst", "rev": "reviewer", "vee": "viewer"}, f)
    a = Axiom0(str(tmp_path))
    a.ingest("howard", SOURCES)
    return a


# ---- truth library ----------------------------------------------------------
def test_sections_parsed_and_hashed(ax):
    cites = {s.cite for s in ax.library.current()}
    assert cites == {"sample-charter:101", "sample-charter:210",
                     "sample-code-ch2:2-13", "sample-code-ch2:2-14"}
    assert all(len(s.sha256) == 64 for s in ax.library.current())


def test_changed_section_is_versioned_not_overwritten(ax, tmp_path):
    src = open(os.path.join(SOURCES, "sample-ordinance-ch2.md")).read()
    changed = src.replace("fourteen days", "twenty-one days")
    rep = ax.library.ingest_text(changed)
    assert [c["section"] for c in rep["changed"]] == ["2-13"]
    assert ax.library.get("sample-code-ch2:2-13").version == 2
    old = ax.library.get("sample-code-ch2:2-13", version=1)
    assert "fourteen days" in old.text  # the original text is still provable


def test_reingest_unchanged_records_nothing(ax):
    before = len(ax.ledger.entries())
    ax.monitor("howard", SOURCES)
    assert len(ax.ledger.entries()) == before


# ---- proof gate -------------------------------------------------------------
def test_proof_gate_accepts_verbatim_and_rejects_invented(ax):
    v = check_claims([
        {"text": "Requests go to the clerk 14 days ahead.", "cite": "sample-code-ch2:2-13",
         "quote": "submitted to the city clerk at least fourteen days before the event"},
        {"text": "Requests are free.", "cite": "sample-code-ch2:2-14",
         "quote": "reservations are free of charge for residents"},
        {"text": "Made up section.", "cite": "sample-code-ch2:9-99",
         "quote": "this section does not exist anywhere"},
        {"text": "Too short.", "cite": "sample-code-ch2:2-14", "quote": "reservation fee"},
    ], ax.library)
    assert len(v.proven) == 1 and v.proven[0]["cite"].startswith("sample-code-ch2:2-13@v1#")
    reasons = sorted(r["reason"] for r in v.rejected)
    assert any("does not appear" in r for r in reasons)
    assert any("not found" in r for r in reasons)
    assert any("shorter" in r for r in reasons)


def test_ask_extractive_is_proven_and_logged(ax):
    r = ax.ask("vee", "How many days before the event must a chamber reservation be submitted?",
               use_llm=False)
    assert r["status"] == "proven"
    assert r["findings"][0]["cite"].startswith("sample-code-ch2:2-13")
    assert "fourteen days" in r["findings"][0]["quote"]
    assert ax.ledger.entries("answer")[-1]["seq"] == r["ledger_seq"]


def test_ask_with_no_evidence(ax):
    r = ax.ask("vee", "zoning setback for accessory dwelling units", use_llm=False)
    assert r["status"] in {"no_evidence", "unproven"} and not r["findings"]


def test_charter_ranks_above_ordinance(ax):
    r = ax.ask("vee", "city clerk records council reservation request", use_llm=False)
    ranks = [f["authority_rank"] for f in r["findings"]]
    assert ranks == sorted(ranks)


# ---- ledger -----------------------------------------------------------------
def test_ledger_genesis_anchored_to_v01(ax):
    g = ax.ledger.entries()[0]
    assert g["kind"] == "genesis" and g["payload"]["anchor_sha256"] == V01_PACKAGE_SHA256


def test_ledger_is_append_only_and_detects_tampering(tmp_path):
    db = sqlite3.connect(str(tmp_path / "l.db"))
    led = Ledger(db)
    led.append("a", "note", {"x": 1})
    led.append("a", "note", {"x": 2})
    assert led.verify()[0]
    with pytest.raises(sqlite3.DatabaseError):
        db.execute("UPDATE ledger SET payload='{\"x\":9}' WHERE seq=2")
    # Simulate someone bypassing the trigger.
    db.execute("DROP TRIGGER ledger_no_update")
    db.execute("UPDATE ledger SET payload='{\"x\":9}' WHERE seq=2")
    ok, msg = led.verify()
    assert not ok and "entry 2" in msg


# ---- access and limits ------------------------------------------------------
def test_roles_enforced(ax):
    with pytest.raises(AccessDenied):
        ax.ingest("vee", SOURCES)
    with pytest.raises(AccessDenied):
        ax.warn("vee", CSV)
    with pytest.raises(AccessDenied):
        ax.ask("stranger", "anything")


@pytest.mark.parametrize("action", ["issue_citation", "authorize_spending",
                                    "modify_official_record", "person_level_risk_score"])
def test_forbidden_even_for_admin(ax, action):
    with pytest.raises(AccessDenied):
        ax.users.require("howard", action)


# ---- early warning and review -----------------------------------------------
def test_spike_rule_math():
    end = date(2026, 6, 30)
    rows = []
    for i in range(1, 7):  # 2 per baseline window
        for k in range(2):
            rows.append((end - timedelta(days=30 * i + k), "A", "sewer"))
    for k in range(9):     # 9 in the current window
        rows.append((end - timedelta(days=k), "A", "sewer"))
    f = spikes(rows, SpikeRule(), as_of=end)
    assert len(f) == 1 and f[0].count == 9 and f[0].baseline_mean == 2.0 and f[0].threshold == 2.0


def test_person_columns_refused(tmp_path, ax):
    p = tmp_path / "bad.csv"
    p.write_text("date,area,category,owner_name\n2026-01-01,A,sewer,Someone\n")
    with pytest.raises(ValueError):
        ax.warn("ana", str(p))


def test_warning_flows_to_review_queue(ax):
    flags = ax.warn("ana", CSV)
    assert any(f["area"].endswith("Area B") and f["category"] == "sewer backup" for f in flags)
    q = ax.queue()
    assert len(q) == len(flags)
    with pytest.raises(PermissionError):
        ax.review("ana", q[0]["seq"], "approved")  # analyst cannot review
    ax.review("rev", q[0]["seq"], "approved", "send to public works")
    assert len(ax.queue()) == len(flags) - 1
    with pytest.raises(ValueError):
        ax.review("rev", q[0]["seq"], "rejected")  # no second decision
    assert ax.ledger.verify()[0]


def test_reviewer_cannot_approve_own_recommendation(ax):
    ax.users.roles["rev"] = "reviewer"
    rec = ax.recommend("rev", "self-authored")
    with pytest.raises(PermissionError):
        ax.review("rev", rec["seq"], "approved")


def test_lineage_not_linked_without_package(monkeypatch):
    monkeypatch.delenv("AXIOM0_V01_PACKAGE", raising=False)
    assert check_v01().status == "not_linked"
