# AXIOM0 Municipal Intelligence Core — v0.2

**Truth exists before proof.** Official sources are loaded, hashed, and versioned before any question is asked. Every statement AXIOM0 makes has to cite a source section and quote it word for word, or it is dropped. Every answer, warning, and decision goes into a hash-chained ledger whose first entry is anchored to the AXIOM0 v0.1 specification package (`7e73c982…b8d0`).

v0.1 (the Protected-12 rule, Genesis and Soul vectors, resonance and harmony equations) is not rewritten here. Its spec and test vectors remain the reference, and `axiom0 lineage` checks that the package on disk matches its recorded hash.

## The five functions

| # | Function | File | What it guarantees |
|---|---|---|---|
| 1 | Charter and Code Library | `truth.py` | Sections are hashed. A change creates a new version and the old text is kept, so a past answer can always be checked against what it cited. Charter > ordinance > policy > procedure. |
| 2 | Municipal Research Agent | `research.py`, `proof.py`, `llm.py` | Retrieval → optional local-model draft → **Proof Gate**. A claim passes only if its cited section exists and contains the quote verbatim (5+ words). Without Ollama it runs extractively and returns exact source sentences. |
| 3 | Continuous Monitoring | `core.monitor()` | Re-ingesting a folder records only real changes (added/changed/removed sections, with old→new hashes). Schedule it with cron or Task Scheduler. |
| 4 | Early-Warning Indicators | `warning.py` | SPIKE-v1: the latest 30-day count vs. the previous six windows (flags at mean + 2 sd and at least 5 requests). Every flag shows its numbers so anyone can recompute it. Area-level only: files with person-identifying columns are refused. |
| 5 | Accountability Ledger | `ledger.py` | Append-only (database triggers block edits and deletes) and hash-chained (`axiom0 ledger --verify` pinpoints any altered entry). |

**Limits that apply even to admins:** AXIOM0 never issues citations, makes enforcement decisions, authorizes spending, modifies official records, or scores individuals. Recommendations wait in a review queue and need a reviewer who isn't the author.

## Quick start

```bash
pip install -e .                      # no runtime dependencies; pytest for tests
axiom0 init --admin howard
export AXIOM0_USER=howard
axiom0 user analyst1 analyst
axiom0 user clerk2 reviewer
axiom0 ingest samples/sources         # replace with the official texts
axiom0 ask "How far ahead must a chambers reservation be requested?"
AXIOM0_USER=analyst1 axiom0 warn samples/service_requests_sample.csv
axiom0 queue
AXIOM0_USER=clerk2 axiom0 review 9 approved --note "forward to Water Services"
axiom0 ledger --verify
AXIOM0_V01_PACKAGE=/path/to/axiom0-v0.1.zip axiom0 lineage
python -m pytest -q                   # 19 tests
```

**Local model (optional):** install Ollama, then `ollama pull qwen2.5:14b-instruct`. AXIOM0 detects it automatically. To change the model, set `AXIOM0_MODEL`. To force extractive mode, use `--no-llm`.

## Loading real sources

Put each document in a `.md` or `.txt` file with a header block (`doc_id`, `title`, `authority`, `effective`, `source_url`). Sections start with `Sec. 2-13.`, `Section 101.`, `§ 2-13`, or `## 2-13 Title`. The files in `samples/sources` are **fictional fixtures**, not official text.

## Deployment shape

v0.2 runs on one workstation with SQLite. The interfaces (`Axiom0.ask/ingest/warn/review`) are designed to sit behind a FastAPI service with real sign-in when it becomes a central server. At that point, move to PostgreSQL + pgvector for storage and embedding search alongside the current BM25 ranking. Connect Clerk Access and Chambers Desk through separate read-only, permission-scoped APIs.
