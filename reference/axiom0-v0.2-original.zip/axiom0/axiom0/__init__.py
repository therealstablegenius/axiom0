"""AXIOM0 Municipal Intelligence Core (v0.2).

Founding rule: truth exists before proof.
  * Truth  = official sources, hashed and versioned before any question is asked.
  * Proof  = every statement AXIOM0 makes must point to a source section and
             quote it word for word. A statement that cannot be proven is dropped.
  * Record = every finding, answer, and decision goes into a hash-chained ledger
             anchored to the AXIOM0 v0.1 specification package.
"""

__version__ = "0.2.0"
