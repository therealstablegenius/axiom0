"""Accountability Ledger: append-only, hash-chained record.

Each entry stores the hash of the entry before it. Changing or deleting any
past entry breaks every hash after it, and verify() reports where.
The genesis entry is anchored to the AXIOM0 v0.1 package hash.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone

from .lineage import V01_PACKAGE_SHA256

GENESIS_PREV = "0" * 64


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _entry_hash(prev_hash: str, ts: str, actor: str, kind: str, payload: dict) -> str:
    body = _canon({"prev": prev_hash, "ts": ts, "actor": actor, "kind": kind, "payload": payload})
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


class Ledger:
    def __init__(self, db: sqlite3.Connection):
        self.db = db
        db.execute(
            """CREATE TABLE IF NOT EXISTS ledger (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL, actor TEXT NOT NULL, kind TEXT NOT NULL,
                payload TEXT NOT NULL, prev_hash TEXT NOT NULL, entry_hash TEXT NOT NULL UNIQUE)"""
        )
        # Block edits and deletes at the database level as well.
        db.execute(
            """CREATE TRIGGER IF NOT EXISTS ledger_no_update BEFORE UPDATE ON ledger
               BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END"""
        )
        db.execute(
            """CREATE TRIGGER IF NOT EXISTS ledger_no_delete BEFORE DELETE ON ledger
               BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END"""
        )
        db.commit()
        if self._last() is None:
            self.append("system", "genesis", {
                "anchor": "AXIOM0 v0.1 specification package",
                "anchor_sha256": V01_PACKAGE_SHA256,
                "rule": "truth exists before proof",
            })

    def _last(self):
        return self.db.execute(
            "SELECT seq, entry_hash FROM ledger ORDER BY seq DESC LIMIT 1").fetchone()

    def append(self, actor: str, kind: str, payload: dict) -> dict:
        last = self._last()
        prev = last[1] if last else GENESIS_PREV
        ts = _now()
        h = _entry_hash(prev, ts, actor, kind, payload)
        cur = self.db.execute(
            "INSERT INTO ledger (ts, actor, kind, payload, prev_hash, entry_hash) VALUES (?,?,?,?,?,?)",
            (ts, actor, kind, _canon(payload), prev, h),
        )
        self.db.commit()
        return {"seq": cur.lastrowid, "ts": ts, "actor": actor, "kind": kind,
                "payload": payload, "entry_hash": h}

    def entries(self, kind: str | None = None) -> list[dict]:
        q = "SELECT seq, ts, actor, kind, payload, prev_hash, entry_hash FROM ledger"
        args: tuple = ()
        if kind:
            q += " WHERE kind = ?"
            args = (kind,)
        rows = self.db.execute(q + " ORDER BY seq", args).fetchall()
        return [{"seq": r[0], "ts": r[1], "actor": r[2], "kind": r[3],
                 "payload": json.loads(r[4]), "prev_hash": r[5], "entry_hash": r[6]} for r in rows]

    def verify(self) -> tuple[bool, str]:
        prev = GENESIS_PREV
        for e in self.entries():
            if e["prev_hash"] != prev:
                return False, f"chain broken at entry {e['seq']} (prev_hash mismatch)"
            expect = _entry_hash(prev, e["ts"], e["actor"], e["kind"], e["payload"])
            if expect != e["entry_hash"]:
                return False, f"entry {e['seq']} was altered (hash mismatch)"
            prev = e["entry_hash"]
        return True, f"ledger intact: {len(self.entries())} entries"
