"""Municipal Research Agent: retrieve, draft, prove, record."""

from __future__ import annotations

from . import llm
from .proof import check_claims
from .retrieve import best_sentences, bm25
from .truth import TruthLibrary

DISCLAIMER = ("Describes what the cited text says. Not a legal determination; "
              "conflicts with state or federal law go to legal review.")


def extractive_claims(question: str, hits) -> list[dict]:
    claims = []
    for sec, _score in hits:
        for sent in best_sentences(question, sec.text):
            claims.append({"text": sent, "cite": sec.cite, "quote": sent})
    return claims


def research(question: str, library: TruthLibrary, k: int = 4, use_llm: bool | None = None) -> dict:
    hits = bm25(question, library.current(), k=k)
    if not hits:
        return {"question": question, "mode": "none", "status": "no_evidence",
                "findings": [], "rejected": [], "confidence": 0.0,
                "note": "No section of the loaded sources matches this question.",
                "disclaimer": DISCLAIMER}

    # Keep only sections that match at least half as well as the best one.
    hits = [h for h in hits if h[1] >= 0.5 * hits[0][1]]
    mode = "extractive"
    if use_llm is None:
        use_llm = llm.available()
    claims = None
    if use_llm:
        try:
            claims = llm.draft_claims(question, [s for s, _ in hits])
            mode = "llm+proof"
        except Exception as e:  # model down, bad JSON, timeout: fall back, never guess
            mode = f"extractive (model error: {type(e).__name__})"
    if not claims:
        claims = extractive_claims(question, hits)
        if mode == "llm+proof":
            mode = "extractive (model returned no claims)"

    verdict = check_claims(claims, library)
    top = hits[0][1]
    coverage = min(1.0, top / 8.0)  # rough: how strongly the best section matched
    confidence = round(verdict.ratio * coverage, 2) if verdict.proven else 0.0
    authorities = sorted({p["authority"] for p in verdict.proven})
    return {
        "question": question,
        "mode": mode,
        "status": "proven" if verdict.proven else "unproven",
        "findings": verdict.proven,
        "rejected": verdict.rejected,
        "confidence": confidence,
        "authorities": authorities,
        "note": ("Multiple authority levels cited; the higher authority (listed first) governs "
                 "local conflicts." if len(authorities) > 1 else ""),
        "disclaimer": DISCLAIMER,
    }
