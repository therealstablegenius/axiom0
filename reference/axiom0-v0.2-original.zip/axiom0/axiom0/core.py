"""AXIOM0 Municipal Intelligence Core: ties the five functions together.

  1. Truth Library        (truth.py)    official sources, hashed and versioned
  2. Research Agent       (research.py) answers that survive the Proof Gate
  3. Continuous Monitoring (monitor())  re-ingest sources, record every change
  4. Early Warning        (warning.py)  defined, testable area-level indicators
  5. Accountability Ledger (ledger.py)  hash-chained record of all of the above

Every action checks access first and is written to the ledger after.
Recommendations wait in a review queue; a reviewer other than the author
must approve or reject them. AXIOM0 itself never takes consequential action.
"""

from __future__ import annotations

import glob
import os
import sqlite3

from .access import Users
from .ledger import Ledger
from .research import research
from .truth import TruthLibrary
from .warning import SpikeRule, flags_as_dicts, load_requests, spikes


class Axiom0:
    def __init__(self, data_dir: str):
        os.makedirs(data_dir, exist_ok=True)
        self.data_dir = data_dir
        self.db = sqlite3.connect(os.path.join(data_dir, "axiom0.db"))
        self.library = TruthLibrary(self.db)
        self.ledger = Ledger(self.db)
        self.users = Users(os.path.join(data_dir, "users.json"))

    # ---- 1 + 3: truth library and monitoring -------------------------------
    def ingest(self, user: str, path: str) -> list[dict]:
        self.users.require(user, "ingest")
        files = sorted(glob.glob(os.path.join(path, "*.md")) + glob.glob(os.path.join(path, "*.txt"))) \
            if os.path.isdir(path) else [path]
        reports = []
        for f in files:
            rep = self.library.ingest_file(f)
            rep["file"] = os.path.basename(f)
            reports.append(rep)
            if rep["added"] or rep["changed"] or rep["removed"]:
                self.ledger.append(user, "source_change", rep)
        return reports

    monitor = ingest  # scheduled monitoring is a re-ingest; only changes are recorded

    # ---- 2: research ------------------------------------------------------
    def ask(self, user: str, question: str, use_llm: bool | None = None) -> dict:
        self.users.require(user, "ask")
        result = research(question, self.library, use_llm=use_llm)
        entry = self.ledger.append(user, "answer", {
            "question": question, "mode": result["mode"], "status": result["status"],
            "confidence": result["confidence"],
            "cited": [f["cite"] for f in result["findings"]],
            "rejected_claims": len(result["rejected"]),
        })
        result["ledger_seq"] = entry["seq"]
        return result

    # ---- 4: early warning -------------------------------------------------
    def warn(self, user: str, csv_path: str, rule: SpikeRule = SpikeRule()) -> list[dict]:
        self.users.require(user, "run_warnings")
        flags = flags_as_dicts(spikes(load_requests(csv_path), rule))
        for f in flags:
            e = self.ledger.append(user, "warning", f)
            self.recommend(user,
                           f"Review {f['category']} service requests in {f['area']}: "
                           f"{f['count']} in {f['window_start']}..{f['window_end']} vs baseline "
                           f"mean {f['baseline_mean']} (threshold {f['threshold']}).",
                           evidence={"warning_seq": e["seq"]})
        return flags

    # ---- 5: review queue --------------------------------------------------
    def recommend(self, user: str, text: str, evidence: dict | None = None) -> dict:
        self.users.require(user, "recommend")
        return self.ledger.append(user, "recommendation",
                                  {"text": text, "evidence": evidence or {}, "status": "pending_review"})

    def queue(self) -> list[dict]:
        reviewed = {e["payload"]["recommendation_seq"] for e in self.ledger.entries("review")}
        return [e for e in self.ledger.entries("recommendation") if e["seq"] not in reviewed]

    def review(self, user: str, rec_seq: int, decision: str, note: str = "") -> dict:
        self.users.require(user, "review")
        if decision not in {"approved", "rejected"}:
            raise ValueError("decision must be 'approved' or 'rejected'")
        rec = next((e for e in self.ledger.entries("recommendation") if e["seq"] == rec_seq), None)
        if rec is None:
            raise ValueError(f"no recommendation #{rec_seq}")
        if rec not in self.queue():
            raise ValueError(f"recommendation #{rec_seq} was already reviewed")
        if rec["actor"] == user:
            raise PermissionError("a recommendation must be reviewed by someone other than its author")
        return self.ledger.append(user, "review", {
            "recommendation_seq": rec_seq, "decision": decision, "note": note,
            "next_step": "route to the responsible department through its normal process"
                         if decision == "approved" else "closed"})
