"""Link to the AXIOM0 v0.1 specification package.

v0.1 (the protected symbolic numerical system: Protected-12 rule, Genesis and
Soul vectors, resonance and harmony equations) is NOT re-implemented here.
Its specification, test vectors and reference code remain the source of truth.
This module only checks that the package on disk is the exact one recorded,
and supplies its hash as the anchor for the ledger's genesis entry.
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass

V01_PACKAGE_SHA256 = "7e73c982145db1ce584f981288e805e683cb2333b24fffb954a048facee3b8d0"


@dataclass
class Lineage:
    status: str          # "verified", "mismatch", or "not_linked"
    expected: str
    actual: str | None
    path: str | None


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def check_v01(path: str | None = None) -> Lineage:
    """Verify the v0.1 package. Path comes from the argument or AXIOM0_V01_PACKAGE."""
    path = path or os.environ.get("AXIOM0_V01_PACKAGE")
    if not path or not os.path.isfile(path):
        return Lineage("not_linked", V01_PACKAGE_SHA256, None, path)
    actual = sha256_file(path)
    status = "verified" if actual == V01_PACKAGE_SHA256 else "mismatch"
    return Lineage(status, V01_PACKAGE_SHA256, actual, path)
