"""Command line for AXIOM0.

  axiom0 init   --admin howard
  axiom0 ingest  <file-or-folder>          (admin)  load or re-check sources
  axiom0 ask     "question"                (viewer) proven answer with citations
  axiom0 warn    requests.csv              (analyst) run early-warning indicators
  axiom0 queue                             list recommendations awaiting review
  axiom0 review  <seq> approved|rejected   (reviewer, not the author)
  axiom0 ledger  [--verify]                show or verify the record
  axiom0 lineage                           check the v0.1 package hash
  axiom0 user    <name> <role>             (admin) add or change a user

Global options: --data DIR (default ./axiom0_data), --user NAME (default $AXIOM0_USER).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import textwrap

from .access import ROLE_RANK, AccessDenied
from .core import Axiom0
from .lineage import check_v01
from .warning import SpikeRule


def _print_answer(r: dict) -> None:
    print(f"\nQ: {r['question']}")
    print(f"Status: {r['status']}   Mode: {r['mode']}   Confidence: {r['confidence']}"
          f"   Ledger #{r.get('ledger_seq')}")
    if not r["findings"]:
        print("\n" + (r.get("note") or "No claim could be proven from the loaded sources."))
    for i, f in enumerate(r["findings"], 1):
        print(f"\n[{i}] {textwrap.fill(f['text'], 92, subsequent_indent='    ')}")
        print(f"    Source: {f['cite']}  ({f['authority']}"
              f"{', effective ' + f['effective'] if f['effective'] else ''})")
        if f.get("source_url"):
            print(f"    Official copy: {f['source_url']}")
    if r["rejected"]:
        print(f"\nDropped {len(r['rejected'])} unproven claim(s):")
        for x in r["rejected"]:
            print(f"  - {x.get('cite', '?')}: {x['reason']}")
    if r.get("note") and r["findings"]:
        print(f"\nNote: {r['note']}")
    print(f"\n{r['disclaimer']}")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="axiom0", description="AXIOM0 Municipal Intelligence Core")
    p.add_argument("--data", default=os.environ.get("AXIOM0_DATA", "axiom0_data"))
    p.add_argument("--user", default=os.environ.get("AXIOM0_USER"))
    p.add_argument("--json", action="store_true", help="print raw JSON")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init"); s.add_argument("--admin", required=True)
    s = sub.add_parser("user"); s.add_argument("name"); s.add_argument("role", choices=list(ROLE_RANK))
    s = sub.add_parser("ingest"); s.add_argument("path")
    s = sub.add_parser("ask"); s.add_argument("question")
    s.add_argument("--no-llm", action="store_true", help="extractive mode only")
    s = sub.add_parser("warn"); s.add_argument("csv")
    s.add_argument("--window", type=int, default=30); s.add_argument("--z", type=float, default=2.0)
    s.add_argument("--min-count", type=int, default=5)
    sub.add_parser("queue")
    s = sub.add_parser("review"); s.add_argument("seq", type=int)
    s.add_argument("decision", choices=["approved", "rejected"]); s.add_argument("--note", default="")
    s = sub.add_parser("ledger"); s.add_argument("--verify", action="store_true")
    s.add_argument("--kind")
    s = sub.add_parser("lineage"); s.add_argument("--package")

    a = p.parse_args(argv)

    if a.cmd == "lineage":
        lin = check_v01(a.package)
        print(json.dumps(lin.__dict__, indent=2))
        return 0 if lin.status != "mismatch" else 2

    if a.cmd == "init":
        os.makedirs(a.data, exist_ok=True)
        path = os.path.join(a.data, "users.json")
        if os.path.exists(path):
            print(f"{path} already exists; use 'axiom0 user' to change roles.")
            return 1
        with open(path, "w", encoding="utf-8") as f:
            json.dump({a.admin: "admin"}, f, indent=2)
        ax = Axiom0(a.data)
        ax.ledger.append(a.admin, "init", {"admin": a.admin})
        print(f"Initialized {a.data} with admin '{a.admin}'. Ledger genesis anchored to v0.1.")
        return 0

    ax = Axiom0(a.data)
    try:
        if a.cmd in {"ingest", "ask", "warn", "review", "user"} and not a.user:
            raise AccessDenied("set --user or AXIOM0_USER")

        if a.cmd == "user":
            ax.users.require(a.user, "ingest")  # admin-only
            ax.users.roles[a.name] = a.role
            with open(ax.users.path, "w", encoding="utf-8") as f:
                json.dump(ax.users.roles, f, indent=2)
            ax.ledger.append(a.user, "role_change", {"user": a.name, "role": a.role})
            print(f"{a.name} -> {a.role}")

        elif a.cmd == "ingest":
            for rep in ax.ingest(a.user, a.path):
                print(f"{rep['file']}: {rep['doc_id']}  +{len(rep['added'])} added  "
                      f"~{len(rep['changed'])} changed  -{len(rep['removed'])} removed  "
                      f"={rep['unchanged']} unchanged")
                for c in rep["changed"]:
                    print(f"    changed {c['section']}: {c['from']} -> {c['to']}")

        elif a.cmd == "ask":
            r = ax.ask(a.user, a.question, use_llm=False if a.no_llm else None)
            print(json.dumps(r, indent=2)) if a.json else _print_answer(r)

        elif a.cmd == "warn":
            flags = ax.warn(a.user, a.csv, SpikeRule(window_days=a.window, z=a.z, min_count=a.min_count))
            if a.json:
                print(json.dumps(flags, indent=2))
            elif not flags:
                print("No indicator crossed its threshold.")
            for f in flags:
                print(f"[{f['rule']}] {f['area']} / {f['category']}: {f['count']} "
                      f"({f['window_start']}..{f['window_end']})  baseline {f['baseline_counts']} "
                      f"mean {f['baseline_mean']} sd {f['baseline_stdev']} threshold {f['threshold']}")
            if flags:
                print(f"\n{len(flags)} recommendation(s) added to the review queue.")

        elif a.cmd == "queue":
            q = ax.queue()
            if not q:
                print("Review queue is empty.")
            for e in q:
                print(f"#{e['seq']}  by {e['actor']}  {e['ts']}\n    {e['payload']['text']}")

        elif a.cmd == "review":
            e = ax.review(a.user, a.seq, a.decision, a.note)
            print(f"Recorded as ledger #{e['seq']}: {a.decision}. {e['payload']['next_step']}.")

        elif a.cmd == "ledger":
            if a.verify:
                ok, msg = ax.ledger.verify()
                print(("OK: " if ok else "FAILED: ") + msg)
                return 0 if ok else 2
            for e in ax.ledger.entries(a.kind):
                print(f"#{e['seq']} {e['ts']} {e['actor']:<10} {e['kind']:<15} {e['entry_hash'][:16]}")
        return 0
    except (AccessDenied, PermissionError, ValueError) as e:
        print(f"Refused: {e}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main())
