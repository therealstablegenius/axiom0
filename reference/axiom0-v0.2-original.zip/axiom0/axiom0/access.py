"""Role-based access and hard limits on what AXIOM0 may ever do.

Some actions are forbidden for every role, including admin. AXIOM0 can
research, explain, and recommend. It never decides, enforces, or spends.
"""

from __future__ import annotations

import json
import os

ROLE_RANK = {"viewer": 1, "analyst": 2, "reviewer": 3, "admin": 4}

ACTION_MIN_ROLE = {
    "ask": "viewer",
    "read_ledger": "viewer",
    "run_warnings": "analyst",
    "recommend": "analyst",
    "review": "reviewer",
    "ingest": "admin",
}

# Never permitted through AXIOM0, whatever the role.
FORBIDDEN_ACTIONS = {
    "issue_citation",
    "enforcement_decision",
    "authorize_spending",
    "modify_official_record",
    "person_level_risk_score",
}


class AccessDenied(PermissionError):
    pass


class Users:
    """Loads users.json: {"name": "role", ...}."""

    def __init__(self, path: str):
        self.path = path
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                self.roles = json.load(f)
        else:
            self.roles = {}

    def role_of(self, user: str) -> str:
        if user not in self.roles:
            raise AccessDenied(f"unknown user '{user}'")
        role = self.roles[user]
        if role not in ROLE_RANK:
            raise AccessDenied(f"user '{user}' has invalid role '{role}'")
        return role

    def require(self, user: str, action: str) -> str:
        if action in FORBIDDEN_ACTIONS:
            raise AccessDenied(f"'{action}' is outside AXIOM0's authority; route it through the "
                               "responsible official and the authorized process")
        if action not in ACTION_MIN_ROLE:
            raise AccessDenied(f"unknown action '{action}'")
        role = self.role_of(user)
        if ROLE_RANK[role] < ROLE_RANK[ACTION_MIN_ROLE[action]]:
            raise AccessDenied(f"'{user}' ({role}) may not '{action}'; "
                               f"requires {ACTION_MIN_ROLE[action]}")
        return role
